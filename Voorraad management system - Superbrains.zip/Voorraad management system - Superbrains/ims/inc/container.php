</head>
<body class="bg-gradient bg-dark bg-opacity-25">
<nav role="navigation" class="navbar navbar-dark navbar-static-top bg-primary bg-gradient">
    <div class="container">
      <div class="navbar-header">
        <a href="https://www.superbrains.nl/" class="navbar-brand">Voorraad management system - Superbrains</a>
        <style>
      p. {
        font-family: "Arial",;
      }
      </style>
      </div>
    </div>
  </nav>

	<div class="container">
